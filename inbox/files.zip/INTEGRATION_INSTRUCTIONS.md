# 🎮 STRIPE INTEGRATION - READY TO APPLY!

## 📋 WHAT TO DO

### **Step 1: Copy the Stripe HTML**

Find this section in `index.html` (around line 1115):
```html
<!-- Sponsor Section -->
<div style="margin-bottom: 32px;">
  ...Patreon button...
</div>
```

**Replace with:**
```html
<!-- Support Section with Stripe Buy Button -->
<div style="margin-bottom: 32px;">
  <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px; text-transform: uppercase; letter-spacing: 0.05em; font-weight: 600;">
    <img src="assets/icons/heart.png" alt="" width="14" style="vertical-align: middle; margin-right: 4px;">
    Support Development
  </p>
  <p style="font-size: 15px; color: var(--text-secondary); margin-bottom: 12px; line-height: 1.6;">
    Support this project<br>
    <span style="font-size: 13px; color: var(--text-muted);">Optional. Pay what you want.</span>
  </p>
  
  <div id="stripe-button-container" style="margin-bottom: 12px;">
    <script async src="https://js.stripe.com/v3/buy-button.js"></script>
    <stripe-buy-button
      buy-button-id="buy_btn_1SvPgGFkQVrW7ZM5NHW6bgNB"
      publishable-key="pk_live_51SvOS9FkQVrW7ZM5qiiyQM87ZEXV3CoBC7S5QThfVglAtj8GLsThmpVXFwLC3GdtvRkg2Jyt9fAXmQaPxhYP3WLC00uQXIIQBP"
    >
    </stripe-buy-button>
  </div>

  <p style="font-size: 11px; color: var(--text-muted); margin-top: 8px;">
    Secure checkout · Apple Pay · Google Pay · Card
  </p>
</div>
```

---

### **Step 2: Add Mario Styling for Stripe Button**

Find the `<style>` section in the `<head>` and add this CSS:

```css
/* Stripe Buy Button - Mario 3D Styling */
stripe-buy-button {
  display: block;
  width: fit-content;
}

stripe-buy-button::part(button) {
  background: #4CAF50 !important;
  padding: 12px 32px !important;
  padding-bottom: 16px !important;
  font-size: 18px !important;
  font-weight: 700 !important;
  border-radius: 8px !important;
  border: none !important;
  color: white !important;
  cursor: pointer !important;
  transition: all 150ms !important;
  box-shadow: 
    rgba(0, 0, 0, 0.15) 0 4px 12px 0,
    inset 0px -8px 0px rgba(0, 0, 0, 0.15),
    inset 0px -3px 0px rgba(0, 0, 0, 0.2) !important;
}

stripe-buy-button::part(button):hover {
  transform: translateY(-2px) !important;
  filter: brightness(1.05) !important;
}

stripe-buy-button::part(button):active {
  padding-top: 14px !important;
  padding-bottom: 14px !important;
  transform: translateY(2px) !important;
}
```

---

### **Step 3: Test**

```bash
cd W:\code\emojirain-web
start index.html
```

**Check:**
- ✅ Green Mario-style button appears
- ✅ Hover effect works (lifts up)
- ✅ Click effect works (pushes down)
- ✅ Clicking opens Stripe checkout
- ✅ Payment methods show (Apple Pay, Google Pay, Card)

---

### **Step 4: Commit & Push**

```bash
git add -A
git commit -m "feat: Integrate Stripe Buy Button with Mario 3D styling - Pay what you want"
git push
```

---

## 🎨 What It Looks Like

```
┌─────────────────────────────────┐
│   ❤️ SUPPORT DEVELOPMENT        │
│                                 │
│   Support this project          │
│   Optional. Pay what you want.  │
│                                 │
│   ┌───────────────┐             │
│   │   💚 Support  │  ← Mario 3D │
│   └───────────────┘             │
│                                 │
│   Secure checkout · Apple Pay   │
│   · Google Pay · Card           │
└─────────────────────────────────┘
```

---

## ✅ Benefits

1. **Pay What You Want** - Users choose amount
2. **One-Click Payment** - Stripe handles everything
3. **Mobile Optimized** - Apple Pay / Google Pay
4. **Secure** - PCI compliant, Stripe hosted
5. **Professional** - Matches Mario theme perfectly
6. **No Recurring** - One-time payments only

---

## 🚀 READY TO GO!

Just copy the code, test it, and push! 🎮

