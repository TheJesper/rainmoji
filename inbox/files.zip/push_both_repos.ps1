# 🚀 Push Both Emojirain Repos

Write-Host "🎮 EMOJIRAIN - PUSHING BOTH REPOS" -ForegroundColor Cyan
Write-Host "=" * 50

# Repo 1: emojirain-web (Landing Page)
Write-Host "`n📦 Repository 1: emojirain-web" -ForegroundColor Yellow
Write-Host "-" * 50

cd W:\code\emojirain-web

Write-Host "Status:" -ForegroundColor Green
git status --short

Write-Host "`nAdding files..." -ForegroundColor Green
git add -A

Write-Host "`nCommitting..." -ForegroundColor Green
git commit -m "feat: Complete Phase 1-3 - Mario buttons, FatCow icons, Stripe payment, Vite build, Celebration system"

Write-Host "`nPushing to GitHub..." -ForegroundColor Green
git push origin main

Write-Host "`n✅ emojirain-web PUSHED!" -ForegroundColor Green

# Repo 2: emojirain (Main Library)
Write-Host "`n`n📦 Repository 2: emojirain" -ForegroundColor Yellow  
Write-Host "-" * 50

cd W:\code\emojirain

Write-Host "Status:" -ForegroundColor Green
git status --short

# Check if there are changes
$status = git status --porcelain
if ($status) {
    Write-Host "`nAdding files..." -ForegroundColor Green
    git add -A
    
    Write-Host "`nCommitting..." -ForegroundColor Green
    git commit -m "chore: Sync with landing page updates"
    
    Write-Host "`nPushing to GitHub..." -ForegroundColor Green
    git push origin main
    
    Write-Host "`n✅ emojirain PUSHED!" -ForegroundColor Green
} else {
    Write-Host "`n⚠️  No changes to commit in emojirain" -ForegroundColor Yellow
}

Write-Host "`n`n🎉 ALL DONE!" -ForegroundColor Cyan
Write-Host "=" * 50
Write-Host "Both repositories pushed successfully!" -ForegroundColor Green
