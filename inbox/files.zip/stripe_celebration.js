// 🎉 STRIPE PAYMENT SUCCESS CELEBRATION 🎉

// Special celebration emoji collection
const celebrationEmojis = [
  '🎉', '🎊', '🎁', '🎈', // Party
  '💚', '💝', '❤️', '💖', // Hearts (gratitude)
  '⭐', '✨', '🌟', '💫', // Stars
  '🏆', '🥇', '👑', // Victory
  '🪙', '💰', '💵', // Money/coins
  '🙏', '🤗', '😊', '🥳', // Thank you emotions
  '🎵', '🎶', '🔔', // Sound
];

// Ultra celebration - MORE emojis, FASTER, BIGGER
const ultraCelebrationConfig = {
  emojis: celebrationEmojis,
  count: 100, // LOTS of emojis!
  speed: 3, // Fast celebration
  duration: 8000, // 8 seconds of glory
  size: { min: 30, max: 80 }, // Bigger emojis
  layers: {
    front: { speed: 1.5, blur: 0 },
    middle: { speed: 1.0, blur: 0 },
    back: { speed: 0.5, blur: 2 }
  }
};

// Listen for Stripe success
function initStripeSuccessListener() {
  // Method 1: Listen for Stripe checkout success via URL parameter
  const urlParams = new URLSearchParams(window.location.search);
  if (urlParams.get('payment') === 'success') {
    triggerPaymentCelebration();
  }

  // Method 2: Listen for Stripe Web Component events
  document.addEventListener('DOMContentLoaded', () => {
    const stripeBuyButton = document.querySelector('stripe-buy-button');
    
    if (stripeBuyButton) {
      // Stripe emits custom events on success
      stripeBuyButton.addEventListener('load', () => {
        console.log('Stripe button loaded');
      });
    }
  });

  // Method 3: Poll for success redirect
  // Stripe redirects to success_url with ?payment=success
  window.addEventListener('load', () => {
    if (window.location.search.includes('payment_intent')) {
      triggerPaymentCelebration();
    }
  });
}

// TRIGGER THE CELEBRATION! 🎊
function triggerPaymentCelebration() {
  console.log('🎉 PAYMENT SUCCESS! CELEBRATING!');
  
  // Show thank you message
  showThankYouMessage();
  
  // Start emoji rain celebration
  startCelebrationRain();
  
  // Play success sound (if available)
  playSuccessSound();
  
  // Confetti burst effect
  createConfettiBurst();
}

// Thank you message modal/banner
function showThankYouMessage() {
  const banner = document.createElement('div');
  banner.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: linear-gradient(135deg, #4CAF50 0%, #45a049 100%);
    color: white;
    padding: 40px 60px;
    border-radius: 20px;
    box-shadow: 
      rgba(0, 0, 0, 0.3) 0 20px 60px 0,
      inset 0px -8px 0px rgba(0, 0, 0, 0.2);
    z-index: 100000;
    text-align: center;
    font-family: inherit;
    animation: celebrationPop 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
  `;
  
  banner.innerHTML = `
    <div style="font-size: 60px; margin-bottom: 20px;">🎉💚🎊</div>
    <h1 style="font-size: 36px; font-weight: 700; margin: 0 0 16px 0;">
      THANK YOU!
    </h1>
    <p style="font-size: 20px; margin: 0; opacity: 0.9;">
      You're amazing! Your support means the world! 🙏✨
    </p>
  `;
  
  document.body.appendChild(banner);
  
  // Auto-remove after 5 seconds
  setTimeout(() => {
    banner.style.animation = 'celebrationFadeOut 0.5s ease-out';
    setTimeout(() => banner.remove(), 500);
  }, 5000);
}

// Start the emoji rain celebration
function startCelebrationRain() {
  const container = document.getElementById('rainContainer');
  if (!container) return;
  
  // Clear existing emojis
  container.innerHTML = '';
  
  // Create celebration emojis
  for (let i = 0; i < ultraCelebrationConfig.count; i++) {
    setTimeout(() => {
      const emoji = createCelebrationEmoji();
      container.appendChild(emoji);
    }, i * 80); // Staggered for effect
  }
}

// Create a celebration emoji element
function createCelebrationEmoji() {
  const emoji = document.createElement('div');
  const randomEmoji = celebrationEmojis[Math.floor(Math.random() * celebrationEmojis.length)];
  const size = Math.random() * (ultraCelebrationConfig.size.max - ultraCelebrationConfig.size.min) + ultraCelebrationConfig.size.min;
  
  emoji.textContent = randomEmoji;
  emoji.style.cssText = `
    position: absolute;
    left: ${Math.random() * 100}%;
    top: -100px;
    font-size: ${size}px;
    pointer-events: none;
    animation: celebrationFall ${3 + Math.random() * 2}s linear forwards;
    opacity: ${0.8 + Math.random() * 0.2};
    z-index: ${Math.floor(Math.random() * 3) + 1};
  `;
  
  return emoji;
}

// Confetti burst at center
function createConfettiBurst() {
  const colors = ['#4CAF50', '#FFC107', '#E91E63', '#268bd2', '#FFD700'];
  const burstCount = 50;
  
  for (let i = 0; i < burstCount; i++) {
    const confetti = document.createElement('div');
    const angle = (Math.PI * 2 * i) / burstCount;
    const velocity = 200 + Math.random() * 200;
    
    confetti.style.cssText = `
      position: fixed;
      left: 50%;
      top: 50%;
      width: 10px;
      height: 10px;
      background: ${colors[Math.floor(Math.random() * colors.length)]};
      border-radius: 50%;
      pointer-events: none;
      z-index: 99999;
    `;
    
    document.body.appendChild(confetti);
    
    // Animate outward
    const animation = confetti.animate([
      { transform: 'translate(0, 0) scale(1)', opacity: 1 },
      { 
        transform: `translate(${Math.cos(angle) * velocity}px, ${Math.sin(angle) * velocity}px) scale(0)`,
        opacity: 0 
      }
    ], {
      duration: 1000,
      easing: 'cubic-bezier(0, 0.5, 0.5, 1)'
    });
    
    animation.onfinish = () => confetti.remove();
  }
}

// Play success sound (optional)
function playSuccessSound() {
  // Mario coin sound or success chime
  const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBTGH0fPTgjMGHm7A7+OZRQ0LTqnn7rdnHAU7k9nyy34pBSl+zPDajj0JGWm98OScTgwOUqbl8LZjHAY4kdfy0HgoBS1+zO/glkILElmz6OyrWBMJRqDf8r5tIAU6jtDx0oU1Bx9vwu7lnEYOC0+o5O+6ZSAFOZXY8s6AKgUof8zv35hBDBRXsujs') || null;
  
  if (audio) {
    audio.volume = 0.3;
    audio.play().catch(() => console.log('Audio play blocked'));
  }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
  @keyframes celebrationPop {
    0% { transform: translate(-50%, -50%) scale(0); opacity: 0; }
    50% { transform: translate(-50%, -50%) scale(1.1); }
    100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
  }
  
  @keyframes celebrationFadeOut {
    to { opacity: 0; transform: translate(-50%, -50%) scale(0.8); }
  }
  
  @keyframes celebrationFall {
    0% { transform: translateY(0) rotate(0deg); }
    100% { 
      transform: translateY(calc(100vh + 100px)) rotate(${Math.random() * 720 - 360}deg);
      opacity: 0;
    }
  }
`;
document.head.appendChild(style);

// Initialize on page load
initStripeSuccessListener();

// Export for manual triggering
window.triggerPaymentCelebration = triggerPaymentCelebration;
